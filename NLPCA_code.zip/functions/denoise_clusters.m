function [ima_fil,final_estimate]=denoise_clusters(ima_patchs_vect,func_denoising_patches,func_thresholding,func_recontruction,IDX,Patch_width,nb_axis,nb_clusters,m,n)
% denoise_clusters computes the denoising operation cluster by cluster
%                 
%   INPUT:
%     ima_patchs_vect        : collection of patches (matrix)
%     func_denoising_patches : choice of the denoising perform 
%                                (gausiann or poisson are handle)
%     Patch_width            : width of the square patches to consider
%     func_thresholding      : only no thresholding is yet supported
%  	  func_recontruction     : build the representaion of the patches
%                              thanks to the model used (gausiann or 
%                              poisson are handle)
%     IDX                    : indexes of the cluster
%  	  nb_clusters		     : number of clusters choosen
%  	  nb_axis		         : number of axis/components choosen 
%     Patch_width            : width of the square patches to consider
%     m,n                    : size of the original image
%   OUTPUT:
%     ima_fil                : final denoised image
%     final_estimate         : collection of denoised patches
%   
%  [ima_fil,final_estimate]=denoise_clusters(ima_patchs_vect,...
%                           func_denoising_patches,func_thresholding,...
%                           func_recontruction,IDX,Patch_width,nb_axis,...
%                           nb_clusters,m,n)
%   Perform the denoising of the collection of patches and the reprojection
%   to get an estimation of the original image (ima_fil). The function can
%   handle both poisson and gaussian (after Anscombe transform) case.
%
%   Copyright (C) 2012 NL-PCA project
%   Joseph Salmon, Charles-Alban Deledalle, Rebecca Willet, Zachary Harmany
%
%   See The GNU Public License (GPL)

%---------------------------------------------------------------------
%
%   This file is part of NL-PCA.
%
%   NL-PCA is free software: you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as
%   published by the Free Software Foundation, either version 3 of
%   the License, or (at your option) any later version.
%
%   NL-PCA is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You should have received a copy of the GNU General Public
%   License along with NL-PCA.  If not, see
%   <http://www.gnu.org/licenses/>.
%   Joseph Salmon, Charles-Alban Deledalle, Rebecca Willet, Zachary Harmany
%
%   See The GNU Public License (GPL)
final_estimate=zeros(size(ima_patchs_vect));
scores_patches=zeros(size(ima_patchs_vect,1),1);
startv = randn( nb_axis,Patch_width*Patch_width)*1e-5/(Patch_width*Patch_width);


indexes=cell(nb_clusters,1);
ima_ppca_cluster=cell(nb_clusters,1);
ima_patchs_fil_cluster=cell(nb_clusters,1);
for k=1:nb_clusters
    
    indexes{k}=find(IDX==k);
    scores_patches(indexes{k})=length(indexes{k});
    size_cluster=size(scores_patches(indexes{k}),1);
    startu =zeros(size_cluster, nb_axis);      
    ima_ppca_cluster{k}=func_denoising_patches({ima_patchs_vect(indexes{k},:);startu;startv});   
    ima_ppca_cluster{k}= func_thresholding(ima_ppca_cluster{k});           
    ima_patchs_fil_cluster{k}= func_recontruction(ima_ppca_cluster{k});            
    final_estimate(indexes{k},:)=ima_patchs_fil_cluster{k};

end
ima_fil = reprojection_UWA(reshape(final_estimate,[(m-Patch_width+1),(n-Patch_width+1),Patch_width^2]));
