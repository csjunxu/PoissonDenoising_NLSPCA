NLM Local Polynomial Regression (NLM-LPR)
====================================

Revision:	        01/19/2012
Author:                 J. Salmon, C.-A. Deledalle, R. Willet, Z. Harmanay
Web page:               http://josephsalmon.org/code/index_codes.php?page=NLPCA

NLM-PCA is a MATLAB software implementing the denoising algorithm Non Local Means 
with Principal Component Analysis (NLM-PCA) for images damaged by Poisson noise
as presented in:

"Poisson noise reduction with non-local PCA"
J. Salmon, C.-A. Deledalle, R. Willett, Z. Harmany, ICASSP 2012.


NLM-PCA is free software distributed under the GNU Public License
(GPL). NLM-PCA should be used only for nonprofit purposes. Any
unauthorized use of this software for industrial or profit-oriented
activities is expressively prohibited.

LICENSE
=======

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

See LICENSE.txt

HOW TO
======

The program has been written for MATLAB. Please, look at DEMO_NLMPCA_online.m
to use the standard version of NLM-PCA.

MAIN PROGRAM FILES
==================

The main program files are the following:

- DEMO_NLMPCA_online.m :
	A demonstration file illustrating our denoising algorithms.


CONTACT INFORMATION
===================

For any comment, suggestion or question please contact :

Joseph Salmon			joseph.salmon (at) duke.edu
Charles Alban Deledalle 	deledalle (at) telecom.fr
Rebecca Willett	                willett (at) duke.edu
Zachary Harmany			zth (at) duke.edu

Copyright (C) 2012 NLM-PCA project

See The GNU Public License (GPL) in LICENSE.txt

