function ima_patchs = spatial_patchization(im_ini,w)

[m,n] = size(im_ini);

w1=w-1;

m1=m-w1;
n1=n-w1;

ima_patchs=zeros(m1,n1,w^2);
delta=(0:w1)-1;
for j = 1:n1
    
    yrange = mod(delta+j,n)+1;
    
    for i = 1:m1

        xrange = mod(delta+i,m)+1;  

        
        B = im_ini(xrange, yrange);
        ima_patchs(i,j,:) = B(:);
    end
end
