function patchs_ppca = ebmppca_gordon(patchs,startu,startv,func_factorization)

    if size(patchs, 3) > 1
        isimage = 1;
        [M,N,P] = size(patchs);
        MN = M*N;
        patchs = reshape(patchs, MN, P);
    else
        isimage = 0;
        [MN,P] = size(patchs);
    end
    
[u v ] =func_factorization({patchs,startu,startv});        
patchs_ppca.coefs = u;
patchs_ppca.dicos{1}.axis = v;

