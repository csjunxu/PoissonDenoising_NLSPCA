function ima_fil=NL_PCA_cube_3d(ima_nse_poiss,ima_nse_to_cluster,Patch_width,Patch_width_3d,nb_axis,...
                       nb_clusters,func_thresholding,func_recontruction,...
                       func_denoising_patches,func_clustering)


[m,n,q]=size(ima_nse_poiss);
ima_fil=zeros(m,n,q);	
normalization=zeros(m,n,q);	

normalization_band=reprojection_UWA_cube_3d(spatial_patchization_cube_3d(ones(m,n,Patch_width_3d),Patch_width,Patch_width_3d),Patch_width,Patch_width_3d);

%% variant clustering globale
% ima_patchs = ima_nse_poiss(1:end-Patch_width+1,1:end-Patch_width+1,:);
% IDX=ceil(nb_clusters*rand(1,(m-Patch_width+1)*(n-Patch_width+1)));
% [~,IDX_int]=func_clustering({ima_patchs,IDX});


averaged=sum(ima_nse_poiss,3);
ima_patchs = spatial_patchization(averaged, Patch_width);
IDX=ceil(nb_clusters*rand(1,(m-Patch_width+1)*(n-Patch_width+1)));
[~,IDX_int]=func_clustering({ima_patchs,IDX});


% figure
% imagesc(reshape(IDX_int,[m-Patch_width+1,n-Patch_width+1]))
% figure
% imagesc(sum(ima_nse_poiss,3))

% nb_clusters_real=max(IDX_int(:));

clear ima_patchs

for band=1:(q-Patch_width_3d+1)
band
    ima_extracted=ima_nse_to_cluster(:,:,band:+band+Patch_width_3d-1);    
%     ima_patchs_sub_sampled = spatial_patchization_cube(ima_nse_to_cluster(:,:,band:+band+Patch_width_3d-1), Patch_width);
    ima_patchs = spatial_patchization_cube_3d(ima_extracted, Patch_width,Patch_width_3d);

    [~,~,w2]=size(ima_patchs);   
    ima_patchs_vect=reshape(ima_patchs,[(m-Patch_width+1)*(n-Patch_width+1),w2]); 
    clear ima_patchs
    
%     label=ceil(nb_clusters*rand(1,(m-Patch_width+1)*(n-Patch_width+1)));
%     [~,IDX_int]=func_clustering({ima_patchs_sub_sampled,label});
%     nb_clusters=max(IDX_int(:));
    



    ima_fil_int=denoise_clusters_black_cube(ima_patchs_vect,func_denoising_patches,func_thresholding,func_recontruction,IDX_int,Patch_width,nb_axis,nb_clusters,m,n,w2);    
    normalization(:,:,band:+band+Patch_width_3d-1)=normalization(:,:,band:+band+Patch_width_3d-1)+normalization_band;
    ima_fil(:,:,band:band+Patch_width_3d-1)=ima_fil(:,:,band:+band+Patch_width_3d-1)+reprojection_UWA_cube_3d(reshape(ima_fil_int,[(m-Patch_width+1),(n-Patch_width+1),w2]),Patch_width,Patch_width_3d);
    clear ima_patchs_vect


end
ima_fil=ima_fil./normalization;