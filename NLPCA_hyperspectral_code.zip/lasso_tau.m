function y=lasso_tau(M,n,cste)

y=cste*sqrt((log(M)/n));