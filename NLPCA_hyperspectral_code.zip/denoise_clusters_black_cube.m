function final_estimate=denoise_clusters_black_cube(ima_patchs_vect,func_denoising_patches,func_thresholding,func_recontruction,IDX,Patch_width,nb_axis,nb_clusters,m,n,w2)

final_estimate=zeros(size(ima_patchs_vect));
scores_patches=zeros(size(ima_patchs_vect,1),1);

startv = randn( nb_axis,w2);


indexes=cell(nb_clusters,1);
ima_ppca_cluster=cell(nb_clusters,1);
ima_patchs_fil_cluster=cell(nb_clusters,1);

size_cluster=zeros(nb_clusters,1);
best=1;
max_number=0;

for k=1:nb_clusters
    
    indexes{k}=find(IDX==k);
    scores_patches(indexes{k})=length(indexes{k});
    size_cluster(k)=size(scores_patches(indexes{k}),1);
    if length(indexes{k})>max_number
        best=k;
        max_number=length(indexes{k});   
    end    
end
clear scores_patches
value_mean=repmat(mean(ima_patchs_vect(indexes{best},:),2),[1,w2]); 
final_estimate(indexes{best},:)=value_mean;

index=1:nb_clusters;
index(best)=[];
        
for j=1:(nb_clusters-1)

        k=index(j);

%        fprintf('cluster size: %3d\n', size_cluster(k));

        ima_ppca_cluster{k} = func_denoising_patches({ima_patchs_vect(indexes{k},:);zeros(size_cluster(k), nb_axis);startv} );   
        ima_ppca_cluster{k} = func_thresholding(ima_ppca_cluster{k});           
        ima_patchs_fil_cluster{k} = func_recontruction(ima_ppca_cluster{k});            
        final_estimate(indexes{k},:) = ima_patchs_fil_cluster{k};
        ima_ppca_cluster{k} = [];
        ima_patchs_fil_cluster{k} = [];
                
end
