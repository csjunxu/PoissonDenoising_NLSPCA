clear all

%% Image generation
name_image='MoffettField';
%load the test data: 'MoffettField'
urlwrite('http://people.ee.duke.edu/~willett/softwareFiles/MoffettField_TestData.mat','MoffettField_TestData.mat');
f=importdata('MoffettField_TestData.mat');


sd=1;
rng(sd)
ima_ori = f(:,:,1:128)/3; 
[M,N,nb_spect]=size(ima_ori)
ima_nse_poiss = poissrnd(ima_ori);
n = sum(ima_nse_poiss (:))/(M*N*nb_spect)
peak=max(max(ima_ori(:)));


[dim1,dim2,dim3]=size(ima_nse_poiss)
nb_spect_tot=dim3;
nb_photons=sum(ima_nse_poiss(:))/(dim1*dim2*dim3)

%% Parameters:

param.Patch_width=5;
param.Patch_width_3d=23;
param.nb_axis=2; 
param.nb_clusters=30;
param.eps_stop=1e-1; %loop stoping criterion
param.epsilon_cond=1e-3; %condition number for Hessian inversion
param.double_iteration=0;%1 or 2 pass of the whole algorithm
param.nb_iterations=4;
param.bandwith_smooth=2;
param.sub_factor=2;
param.big_cluster1=1;% special case for the biggest cluster 1st pass
param.big_cluster2=1;% special case for the biggest cluster 2nd pass
param.cste=70;
param.func_tau=@(X) lasso_tau(X{1},X{2},param.cste);

%% computation
tic
ima_fil=denoise_poisson_kmeans_poisson_PCA_l1_4d_cube_3d(ima_nse_poiss,param);
toc
 
sprintf('PSNR')
psnr4d(255*ima_fil*3,ima_ori,255)
sprintf('MAE_L1')
MAE_L1(ima_fil,ima_ori)

%% display

G(nb_spect_tot) =struct('cdata',[],'colormap',[]);
scrsz = get(0,'ScreenSize');
fh=figure('Position',[1 1000 1800 800])

for j = 1:nb_spect_tot 

    subplot(1,2,1)
    imagesc( ima_nse_poiss(:,:,j));   
    colormap('gray')    
    title(strcat('Band',32,num2str(j)))
    axis off
    
    subplot(1,2,2)
    imagesc(ima_fil(:,:,j));
    colormap('gray')    
    title(strcat('NLPCA:Band',32,num2str(j)))
    axis off
    
    
    pause(.03);
    G(j) = getframe(fh);
    
end


