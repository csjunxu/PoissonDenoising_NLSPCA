function ima = reprojection_UWA_cube_3d(ima_patchs,w,w_3d)

    [M, N, ~] = size(ima_patchs);

    p = w;
    p1=p-1;
    M1=M+p1;
    N1=N+p1;
    ima = zeros(M+p-1, N+p-1,w_3d);

    delta=(-1)+(1:p)-1;
    
for j = 1:N
    
    yrange = mod(delta+j,N1)+1;
        
    for i = 1:M

        xrange = mod(delta+i,M1)+1;        

        ima(xrange, yrange,:) = ima(xrange, yrange,:) + ...
                                reshape((ima_patchs(i,j,:)), w, w,w_3d);

    end
end
